# Controle de ASO — Ability

Repositório único com as duas partes do sistema. Elas compartilham o **mesmo projeto
Firebase** (`controle-aso-48c88`), mas continuam sendo **dois deploys separados**:

```
painel-aso-monorepo/
├── painel/        → site estático (painel), hospedado onde já está hoje
├── robozinho/      → robô de sync + API de ASOs, deploy próprio na Vercel
└── firestore.rules → regras do Firestore, compartilhadas pelas duas partes
```

## painel/

Site estático puro (`index.html` + `app.js` + `style.css`), fala direto com o Firestore
pelo SDK do navegador. Configuração do Firebase em `firebase-config.js`. Deploy continua
exatamente como já era feito antes — nada mudou aqui além do arquivo ter se mudado de pasta.

Ele chama o robô só num ponto: a constante `ROBOZINHO_API` no topo do `app.js`, usada pra
buscar o PDF do ASO. Depois do primeiro deploy do `robozinho/` na Vercel, troque essa
constante pela URL real (ex: `https://robozinho-aso.vercel.app/api/aso`).

## robozinho/

Robô que lê e-mails de exame, faz OCR e atualiza o Firestore + sobe o PDF criptografado
pro Cloudflare R2. Deploy independente na Vercel (tem seu próprio `vercel.json` com o cron
de sync). Instruções completas de configuração em `robozinho/README.md`.

## firestore.rules

Como as duas partes leem/escrevem nas mesmas coleções (`employees`, `managers`, `_meta`),
as regras ficam num só lugar na raiz do repo. Publique com:

```
firebase deploy --only firestore:rules
```

(usando o Firebase CLI, projeto `controle-aso-48c88`).

## Sobre os dados

O `data.json` com a base atual de colaboradores **não faz parte deste repositório** — é
um dump de dados, não código-fonte, e já está gravado no Firestore. Junte-lo ao repo não é
necessário nem recomendado (evita duplicar dado sensível/de saúde em um lugar a mais).
