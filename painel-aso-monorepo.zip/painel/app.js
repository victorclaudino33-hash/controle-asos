import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import {
  getFirestore, initializeFirestore, persistentLocalCache, persistentMultipleTabManager,
  collection, doc, getDoc, getDocs, setDoc, deleteDoc, onSnapshot, writeBatch, query, where
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import {
  getAuth, onAuthStateChanged, signInWithEmailAndPassword, signOut
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import { firebaseConfig } from "./firebase-config.js";

const fbApp = initializeApp(firebaseConfig);
// Cache local persistente: com 5 mil colaboradores, evita rebaixar a coleção inteira
// a cada login (só o que mudou é lido do servidor). Mesmo banco, mesmas coleções.
let db;
try {
  db = initializeFirestore(fbApp, {
    localCache: persistentLocalCache({ tabManager: persistentMultipleTabManager() })
  });
} catch (e) {
  db = getFirestore(fbApp);
}
const auth = getAuth(fbApp);
const EMPLOYEES_COL = 'employees';
const META_COL = '_meta';
const SYNC_DOC = 'robozinho'; // doc que o robô de leitura de e-mails vai escrever: { lastRun, pendentes }
// URL do projeto do robozinho na Vercel — troque pelo domínio real depois do deploy.
const ROBOZINHO_API = 'https://SEU-PROJETO-ROBOZINHO.vercel.app/api/aso';
const PAGE_SIZE = 50;
let unsubscribeSnapshot = null;
let unsubscribeSyncMeta = null;

const ICONS = {
  search: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#7C8B87" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>',
  plus: '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5"><path d="M12 5v14M5 12h14"/></svg>',
  chevron: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#7C8B87" stroke-width="2"><path d="M6 9l6 6 6-6"/></svg>',
  calendar: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#2E6E8E" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>',
  check: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#2F9E62" stroke-width="2.5"><path d="M20 6L9 17l-5-5"/></svg>',
  edit: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#5B6B67" stroke-width="2"><path d="M12 20h9M16.5 3.5a2.1 2.1 0 013 3L7 19l-4 1 1-4 12.5-12.5z"/></svg>',
  userx: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#C4432E" stroke-width="2"><path d="M16 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="8.5" cy="7" r="4"/><path d="M18 8l4 4M22 8l-4 4"/></svg>',
  usercheck: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#2F9E62" stroke-width="2"><path d="M16 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="8.5" cy="7" r="4"/><path d="M17 11l2 2 4-4"/></svg>',
  trash: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#8A9793" stroke-width="2"><path d="M3 6h18M8 6V4a2 2 0 012-2h4a2 2 0 012 2v2m3 0v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6h14z"/></svg>',
  pause: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#A6631B" stroke-width="2"><rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/></svg>',
  rotate: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#2F9E62" stroke-width="2"><path d="M23 4v6h-6"/><path d="M20.49 15a9 9 0 11-2.12-9.36L23 10"/></svg>',
  x: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#16211F" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>',
  alert: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#C4432E" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><path d="M12 9v4M12 17h.01"/></svg>',
  upload: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>',
  sheet: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9M15 9v12"/></svg>',
  eye: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#2E6E8E" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>',
  clock: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#6B6B6B" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/></svg>',
};

const MESES = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];

const STATUS_META = {
  vencido:   { label: 'Vencido',                 color: 'var(--c-vencido)',   bg: 'var(--c-vencido-bg)' },
  vence30:   { label: 'Vence em 30 dias',         color: 'var(--c-vence30)',   bg: 'var(--c-vence30-bg)' },
  vence90:   { label: 'Vence em 90 dias',         color: 'var(--c-vence90)',   bg: 'var(--c-vence90-bg)' },
  em_dia:    { label: 'Em dia',                   color: 'var(--c-emdia)',     bg: 'var(--c-emdia-bg)' },
  agendado:  { label: 'Agendado',                 color: 'var(--c-agendado)',  bg: 'var(--c-agendado-bg)' },
  sem_exame: { label: 'Sem exame',                color: 'var(--c-semexame)',  bg: 'var(--c-semexame-bg)' },
  afastado:  { label: 'Afastado',                 color: 'var(--c-afastado)',  bg: 'var(--c-afastado-bg)' },
  inativo:   { label: 'Desligado',                color: 'var(--c-inativo)',   bg: 'var(--c-inativo-bg)' },
};

let state = {
  employees: [], busca: '',
  filial: 'Todas', departamento: 'Todos', setor: 'Todos', status: 'Todos',
  page: 1, verPorFilial: false,
  isManager: false, managerSetor: null, managerDepartamento: null, managerFilial: null,
  sortBy: 'vencimento', sortDir: 'asc',
  selecionados: new Set(),
  anoVenc: 'Todos', mesVenc: 'Todos',
  somenteRevisao: false,
  syncMeta: null, // { lastRun: Timestamp|null, pendentes: number } — escrito pelo robô
  tendenciaAberta: false,
};
let buscaDebounceTimer = null;
const today = new Date(); today.setHours(0,0,0,0);

// ---- Filiais ----
// A folha do RH traz o nome truncado do estabelecimento. Normalizamos para um rótulo
// legível e estável — a mesma função é usada na importação, então o valor gravado
// no Firestore é sempre idêntico para a mesma filial.
const FILIAL_MAP = {
  'MATRIZ': 'Matriz',
  'FILIAL OSASCO': 'Osasco',
  'FILIAL RIO DE JANEIR': 'Rio de Janeiro',
  'FILIAL SAO JOSE CAMP': 'São José dos Campos',
  'FILIAL STA CATARINA': 'Santa Catarina',
  'FILIAL BRASILIA': 'Brasília',
  'FILIAL GOIANIA': 'Goiânia',
  'FILIAL RIO GR DO SUL': 'Rio Grande do Sul',
  'FILIAL CUIABA': 'Cuiabá',
  'FILIAL PARANA': 'Paraná',
};
const SEM_FILIAL = 'Não informada';
const FILIAL_LABELS = Object.values(FILIAL_MAP);
function semAcento(s) { return (s ?? '').toString().normalize('NFD').replace(/[\u0300-\u036f]/g, ''); }
function normalizeFilial(v) {
  const raw = (v ?? '').toString().trim();
  if (!raw) return SEM_FILIAL;
  const chave = semAcento(raw).toUpperCase();
  if (FILIAL_MAP[chave]) return FILIAL_MAP[chave];                       // nome cru da planilha
  const jaNormalizada = FILIAL_LABELS.find(l => semAcento(l).toUpperCase() === chave);
  if (jaNormalizada) return jaNormalizada;                               // já veio normalizada do banco
  if (chave === semAcento(SEM_FILIAL).toUpperCase()) return SEM_FILIAL;
  // filial nova, ainda sem mapeamento: "FILIAL XYZ DE ABC" -> "Xyz de Abc"
  const menores = new Set(['de', 'da', 'do', 'das', 'dos', 'e']);
  return raw.replace(/^\s*FILIAL\s+/i, '').toLowerCase().split(/\s+/)
    .map((p, i) => (i > 0 && menores.has(p)) ? p : p.charAt(0).toLocaleUpperCase('pt-BR') + p.slice(1))
    .join(' ');
}
function filialOf(f) { return f.filial || SEM_FILIAL; }

function addMonths(dateStr, months) {
  const d = new Date(dateStr + 'T00:00:00');
  d.setMonth(d.getMonth() + months);
  return d;
}
function fmt(dateStr) {
  if (!dateStr) return '—';
  const d = typeof dateStr === 'string' ? new Date(dateStr + 'T00:00:00') : dateStr;
  return d.toLocaleDateString('pt-BR');
}
function daysBetween(a, b) { return Math.round((a - b) / 86400000); }
function fmtDateTime(ts) {
  if (!ts) return null;
  const d = ts.toDate ? ts.toDate() : new Date(ts);
  return d.toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
}

// ---- Importação de planilhas (novos colaboradores / desligamentos) ----
const FIELD_MAP = {
  nome: 'nome', name: 'nome', colaborador: 'nome',
  nomefunc: 'nome', nomefuncionario: 'nome',                      // BASE NACIONAL
  matricula: 'matricula', re: 'matricula', registro: 'matricula', matriculare: 'matricula',
  codfun: 'matricula', codigofuncionario: 'matricula',            // BASE NACIONAL
  cargo: 'cargo', funcao: 'cargo', função: 'cargo',
  descrnivcarg: 'cargo', descrnivelcargo: 'cargo',                // BASE NACIONAL
  departamento: 'departamento', depto: 'departamento',
  nomedepart: 'departamento', nomedepartamento: 'departamento',   // BASE NACIONAL
  setor: 'setor', area: 'setor',
  nomesetor: 'setor',                                             // BASE NACIONAL
  filial: 'filial', unidade: 'filial', estabelecimento: 'filial',
  nomeestabelecimento: 'filial',                                  // BASE NACIONAL
  ultimadata: 'ultimaData', data: 'ultimaData', dataultimarealizacao: 'ultimaData',
  ultimarealizacao: 'ultimaData', dataexame: 'ultimaData', dataultima: 'ultimaData',
  dataexamemedico: 'ultimaData',                                  // BASE NACIONAL
  admissao: 'admissao', dataadmissao: 'admissao',
  demissao: 'demissao', datademissao: 'demissao', situacao: 'demissao',
  periodicidade: 'periodicidade', meses: 'periodicidade', periodicidademeses: 'periodicidade',
};
function normalizeKey(k) {
  return (k ?? '').toString().trim().toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]/g, '');
}
function parseDateFlexible(val) {
  if (val === undefined || val === null || val === '') return '';
  if (val instanceof Date) {
    const y = val.getFullYear(), m = String(val.getMonth() + 1).padStart(2, '0'), d = String(val.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }
  const s = val.toString().trim();
  let m = s.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})$/);
  if (m) {
    let [, dd, mm, yy] = m;
    if (yy.length === 2) yy = '20' + yy;
    return `${yy}-${mm.padStart(2, '0')}-${dd.padStart(2, '0')}`;
  }
  m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
  if (m) { const [, yy, mm, dd] = m; return `${yy}-${mm.padStart(2, '0')}-${dd.padStart(2, '0')}`; }
  return '';
}
function parseSpreadsheet(file) {
  return new Promise((resolve, reject) => {
    if (!window.XLSX) { reject(new Error('Biblioteca de planilha não carregou. Recarregue a página e tente de novo.')); return; }
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Falha ao ler o arquivo.'));
    reader.onload = (e) => {
      try {
        const wb = window.XLSX.read(e.target.result, { type: 'array', cellDates: true });
        const sheet = wb.Sheets[wb.SheetNames[0]];
        const rows = window.XLSX.utils.sheet_to_json(sheet, { header: 1, raw: true, defval: '' });
        if (!rows.length) { resolve([]); return; }
        const headers = rows[0].map(normalizeKey);
        const objs = rows.slice(1)
          .filter(r => r.some(c => c !== '' && c !== null && c !== undefined))
          .map(r => {
            const obj = {};
            headers.forEach((h, i) => { const field = FIELD_MAP[h]; if (field) obj[field] = r[i]; });
            return obj;
          });
        resolve(objs);
      } catch (err) { reject(new Error('Não consegui ler esse arquivo. Confira se é .xlsx, .xls ou .csv.')); }
    };
    reader.readAsArrayBuffer(file);
  });
}
function isAfastadoFlag(v) {
  return (v ?? '').toString().trim().toUpperCase().startsWith('AFASTAD');
}
// Data de exame implausível (erro de digitação do tipo 2926) vira "sem exame",
// pra não mascarar um vencido como "em dia".
function sanitizeExamDate(iso) {
  if (!iso) return '';
  const ano = Number(iso.slice(0, 4));
  return (ano < 1980 || ano > today.getFullYear() + 1) ? '' : iso;
}
function buildNewEmployeesFromRows(rows) {
  const valid = [], errors = [];
  rows.forEach((r, i) => {
    const nome = (r.nome || '').toString().trim();
    const ultimaData = sanitizeExamDate(parseDateFlexible(r.ultimaData));
    if (!nome) { errors.push(`linha ${i + 2}`); return; }
    const matricula = (r.matricula || '').toString().trim();
    const afastado = isAfastadoFlag(r.demissao);
    valid.push({
      // id = matrícula (mesma convenção já usada no banco) para nunca duplicar colaborador
      id: matricula ? matricula.replace(/[^\w-]/g, '') : 'novo_' + Date.now() + '_' + i,
      nome, matricula,
      cargo: (r.cargo || '').toString().trim(),
      filial: normalizeFilial(r.filial),
      departamento: (r.departamento || '').toString().trim(),
      setor: (r.setor || '').toString().trim(),
      admissao: parseDateFlexible(r.admissao) || '',
      ultimaData,
      periodicidade: Number(r.periodicidade) || 12,
      dataAgendada: '', ativo: true, afastado,
    });
  });
  return { valid, errors };
}

// ---- Sincronização com a base nacional do RH ----
// Regra de ouro: a planilha manda no cadastro (nome, cargo, filial, departamento, setor,
// admissão); o painel manda no acompanhamento (agendamentos, exames lançados na mão,
// periodicidade customizada). Nada é sobrescrito para trás.
function buildSyncPlan(rows, employees) {
  const atuais = new Map(employees.map(f => [f.id, f]));
  const novos = [], atualizados = [], semMudanca = [], revisar = [];
  const vistos = new Set();

  rows.forEach((r, i) => {
    const nome = (r.nome || '').toString().trim();
    const matricula = (r.matricula || '').toString().trim();
    if (!nome || !matricula) { revisar.push(`linha ${i + 2}: sem matrícula ou nome`); return; }
    const id = matricula.replace(/[^\w-]/g, '');
    vistos.add(id);

    const brutaData = parseDateFlexible(r.ultimaData);
    const dataPlanilha = sanitizeExamDate(brutaData);
    if (brutaData && !dataPlanilha) revisar.push(`${matricula} — ${nome}: data de exame inválida (${brutaData})`);
    else if (!brutaData) revisar.push(`${matricula} — ${nome}: sem data de exame`);

    const cadastro = {
      id, nome, matricula,
      cargo: (r.cargo || '').toString().trim(),
      filial: normalizeFilial(r.filial),
      departamento: (r.departamento || '').toString().trim(),
      setor: (r.setor || '').toString().trim(),
      admissao: parseDateFlexible(r.admissao) || '',
    };
    const afastadoPlanilha = isAfastadoFlag(r.demissao);
    const atual = atuais.get(id);

    if (!atual) {
      novos.push({
        ...cadastro, ultimaData: dataPlanilha, periodicidade: 12,
        dataAgendada: '', ativo: true, afastado: afastadoPlanilha,
        dataAfastamento: '', dataRetorno: '', situacao: afastadoPlanilha ? 'Afastado' : 'Ativo',
      });
      return;
    }

    // exame: vence sempre a data mais recente entre painel e planilha
    const ultimaData = (dataPlanilha && (!atual.ultimaData || dataPlanilha > atual.ultimaData))
      ? dataPlanilha : (atual.ultimaData || '');
    // agendamento só é limpo quando o exame já foi realizado depois dele
    const dataAgendada = (atual.dataAgendada && ultimaData && ultimaData >= atual.dataAgendada) ? '' : (atual.dataAgendada || '');
    const patch = { ...cadastro, ultimaData, dataAgendada, ativo: true };

    const mudou = Object.keys(patch).some(k => (atual[k] ?? '') !== (patch[k] ?? ''))
      || (afastadoPlanilha !== !!atual.afastado);
    if (mudou) atualizados.push({ patch, afastadoPlanilha, antes: atual });
    else semMudanca.push(id);
  });

  const ausentes = employees.filter(f => f.ativo && !vistos.has(f.id));
  return { novos, atualizados, semMudanca, ausentes, revisar };
}

async function applySync(plan, opts, onProgress) {
  const writes = [];
  plan.novos.forEach(emp => writes.push([emp.id, emp]));
  plan.atualizados.forEach(({ patch, afastadoPlanilha }) => {
    const dados = { ...patch };
    if (opts.sincronizarAfastamentos) {
      dados.afastado = afastadoPlanilha;
      dados.situacao = afastadoPlanilha ? 'Afastado' : 'Ativo';
      if (!afastadoPlanilha) dados.dataRetorno = dados.dataRetorno || '';
    }
    writes.push([patch.id, dados]);
  });
  if (opts.desligarAusentes) {
    plan.ausentes.forEach(f => writes.push([f.id, { ativo: false, afastado: false, dataAgendada: '', situacao: 'Desligado' }]));
  }
  const CHUNK = 400; // limite do Firestore é 500 operações por lote
  for (let i = 0; i < writes.length; i += CHUNK) {
    const batch = writeBatch(db);
    writes.slice(i, i + CHUNK).forEach(([id, data]) => batch.set(doc(db, EMPLOYEES_COL, id), data, { merge: true }));
    await batch.commit();
    if (onProgress) onProgress(Math.min(i + CHUNK, writes.length), writes.length);
  }
  return writes.length;
}
function buildDismissalsFromRows(rows, employees) {
  const byMatricula = new Map(), byNome = new Map();
  employees.forEach(f => {
    if (f.matricula) byMatricula.set(f.matricula.toString().trim(), f);
    if (f.nome) byNome.set(f.nome.toString().trim().toLowerCase(), f);
  });
  const matched = [], notFound = [];
  rows.forEach(r => {
    const matricula = (r.matricula || '').toString().trim();
    const nome = (r.nome || '').toString().trim();
    let f = matricula ? byMatricula.get(matricula) : null;
    if (!f && nome) f = byNome.get(nome.toLowerCase());
    if (f && f.ativo) matched.push(f.id);
    else if (!f) notFound.push(matricula || nome || '(linha sem matrícula/nome)');
  });
  return { matched, notFound };
}
async function bulkImportNew(list, onProgress) {
  const CHUNK = 400;
  for (let i = 0; i < list.length; i += CHUNK) {
    const batch = writeBatch(db);
    list.slice(i, i + CHUNK).forEach(emp => batch.set(doc(db, EMPLOYEES_COL, emp.id), emp, { merge: true }));
    await batch.commit();
    if (onProgress) onProgress(Math.min(i + CHUNK, list.length), list.length);
  }
}
async function bulkDismiss(ids, onProgress) {
  const CHUNK = 400;
  for (let i = 0; i < ids.length; i += CHUNK) {
    const batch = writeBatch(db);
    ids.slice(i, i + CHUNK).forEach(id => batch.set(doc(db, EMPLOYEES_COL, id), { ativo: false, afastado: false, dataAgendada: '' }, { merge: true }));
    await batch.commit();
    if (onProgress) onProgress(Math.min(i + CHUNK, ids.length), ids.length);
  }
}

// ---- Exportar planilha de indicadores (.xlsx formatado) ----
const STATUS_EXPORT_COLORS = {
  vencido:   { fg: 'FFC4432E', bg: 'FFFBE7E2' },
  vence30:   { fg: 'FFC98A1E', bg: 'FFFBF1DF' },
  vence90:   { fg: 'FFB79A1E', bg: 'FFF8F3D9' },
  em_dia:    { fg: 'FF2F9E62', bg: 'FFE8F5EE' },
  agendado:  { fg: 'FF2E6E8E', bg: 'FFE6F1F6' },
  sem_exame: { fg: 'FF7B5EA7', bg: 'FFEEE9F5' },
  afastado:  { fg: 'FFA6631B', bg: 'FFF5E9DA' },
  inativo:   { fg: 'FF7C8B87', bg: 'FFEEF1F0' },
};
async function exportIndicatorsXlsx() {
  if (!window.ExcelJS) { showToast('Biblioteca de planilha não carregou. Recarregue a página e tente de novo.', true); return; }
  const enriched = getScope();                       // respeita filial/departamento/setor/busca
  const ativos = enriched.filter(f => f.ativo).length;
  const counts = enriched.reduce((acc, f) => { acc[f.status] = (acc[f.status] || 0) + 1; return acc; }, {});
  const setorLabel = scopeLabel();

  const wb = new window.ExcelJS.Workbook();
  wb.creator = 'Painel de ASOs';
  wb.created = new Date();

  // ---- Aba 1: Resumo ----
  const resumo = wb.addWorksheet('Resumo');
  resumo.columns = [{ width: 30 }, { width: 16 }];
  resumo.mergeCells('A1:B1');
  resumo.getCell('A1').value = `Painel de Indicadores — ${setorLabel}`;
  resumo.getCell('A1').font = { bold: true, size: 16, color: { argb: 'FF1A1A1A' } };
  resumo.mergeCells('A2:B2');
  resumo.getCell('A2').value = `Gerado em ${new Date().toLocaleString('pt-BR')}`;
  resumo.getCell('A2').font = { italic: true, size: 10, color: { argb: 'FF6B6B6B' } };
  resumo.addRow([]);

  const headerRow = resumo.addRow(['Indicador', 'Quantidade']);
  headerRow.eachCell(c => {
    c.font = { bold: true, color: { argb: 'FFFFFFFF' } };
    c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1A1A1A' } };
    c.alignment = { horizontal: 'center' };
  });

  const rowsDef = [
    ['Total ativos', ativos, 'FF1A1A1A'],
    ['Em dia', counts.em_dia || 0, STATUS_EXPORT_COLORS.em_dia.fg],
    ['Vence em 90 dias', counts.vence90 || 0, STATUS_EXPORT_COLORS.vence90.fg],
    ['Vence em 30 dias', counts.vence30 || 0, STATUS_EXPORT_COLORS.vence30.fg],
    ['Vencidos', counts.vencido || 0, STATUS_EXPORT_COLORS.vencido.fg],
    ['Agendados', counts.agendado || 0, STATUS_EXPORT_COLORS.agendado.fg],
    ['Sem exame', counts.sem_exame || 0, STATUS_EXPORT_COLORS.sem_exame.fg],
    ['Afastados', counts.afastado || 0, STATUS_EXPORT_COLORS.afastado.fg],
    ['Desligados', counts.inativo || 0, STATUS_EXPORT_COLORS.inativo.fg],
  ];
  rowsDef.forEach(([label, value, color]) => {
    const r = resumo.addRow([label, value]);
    r.getCell(1).font = { color: { argb: color }, bold: true };
    r.getCell(2).font = { color: { argb: color }, bold: true };
    r.getCell(2).alignment = { horizontal: 'center' };
    r.eachCell(c => { c.border = { bottom: { style: 'thin', color: { argb: 'FFDCDCDC' } } }; });
  });

  // ---- Aba 2: Por filial ----
  const porFilial = wb.addWorksheet('Por filial');
  porFilial.columns = [
    { header: 'Filial', key: 'filial', width: 24 },
    { header: 'Ativos', key: 'ativos', width: 10 },
    { header: 'Em dia', key: 'em_dia', width: 10 },
    { header: 'Vence 90', key: 'vence90', width: 11 },
    { header: 'Vence 30', key: 'vence30', width: 11 },
    { header: 'Vencidos', key: 'vencido', width: 11 },
    { header: 'Agendados', key: 'agendado', width: 12 },
    { header: 'Sem exame', key: 'sem_exame', width: 12 },
    { header: 'Afastados', key: 'afastado', width: 11 },
    { header: 'Desligados', key: 'inativo', width: 12 },
    { header: '% em dia', key: 'pct', width: 11 },
  ];
  porFilial.getRow(1).eachCell(c => {
    c.font = { bold: true, color: { argb: 'FFFFFFFF' } };
    c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1A1A1A' } };
  });
  resumoPorFilial(enriched).forEach(l => {
    const row = porFilial.addRow({
      filial: l.filial, ativos: l.ativos, em_dia: l.em_dia, vence90: l.vence90, vence30: l.vence30,
      vencido: l.vencido, agendado: l.agendado, sem_exame: l.sem_exame, afastado: l.afastado,
      inativo: l.inativo, pct: l.ativos ? Math.round((l.em_dia / l.ativos) * 100) / 100 : 0,
    });
    row.getCell('pct').numFmt = '0%';
    row.getCell('vencido').font = { bold: true, color: { argb: STATUS_EXPORT_COLORS.vencido.fg } };
    row.getCell('em_dia').font = { bold: true, color: { argb: STATUS_EXPORT_COLORS.em_dia.fg } };
  });

  // ---- Aba 3: Colaboradores ----
  const det = wb.addWorksheet('Colaboradores');
  det.columns = [
    { header: 'Nome', key: 'nome', width: 30 },
    { header: 'Matrícula', key: 'matricula', width: 14 },
    { header: 'Cargo', key: 'cargo', width: 22 },
    { header: 'Filial', key: 'filial', width: 20 },
    { header: 'Departamento', key: 'departamento', width: 22 },
    { header: 'Setor', key: 'setor', width: 22 },
    { header: 'Última realização', key: 'ultimaData', width: 18 },
    { header: 'Vencimento', key: 'vencimento', width: 16 },
    { header: 'Status', key: 'status', width: 18 },
  ];
  det.getRow(1).eachCell(c => {
    c.font = { bold: true, color: { argb: 'FFFFFFFF' } };
    c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1A1A1A' } };
  });
  enriched
    .filter(f => f.ativo)
    .sort((a, b) => a.status.localeCompare(b.status))
    .forEach(f => {
      const meta = STATUS_META[f.status];
      const colors = STATUS_EXPORT_COLORS[f.status];
      const vencimento = f.ultimaData ? addMonths(f.ultimaData, f.periodicidade || 12) : null;
      const row = det.addRow({
        nome: f.nome, matricula: f.matricula || '', cargo: f.cargo || '',
        filial: filialOf(f), departamento: f.departamento || '', setor: f.setor || '',
        ultimaData: fmt(f.ultimaData), vencimento: vencimento ? fmt(vencimento) : '—', status: meta.label,
      });
      const statusCell = row.getCell('status');
      statusCell.font = { bold: true, color: { argb: colors.fg } };
      statusCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: colors.bg } };
    });

  const buffer = await wb.xlsx.writeBuffer();
  const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `indicadores_${setorLabel.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '_')}_${new Date().toISOString().slice(0, 10)}.xlsx`;
  document.body.appendChild(a); a.click(); a.remove();
  URL.revokeObjectURL(url);
}

function getStatus(f) {
  if (!f.ativo) return 'inativo';
  if (f.afastado) return 'afastado';
  if (f.dataAgendada) {
    const ag = new Date(f.dataAgendada + 'T00:00:00');
    if (ag >= today) return 'agendado';
  }
  if (!f.ultimaData) return 'sem_exame';
  const vencimento = addMonths(f.ultimaData, f.periodicidade || 12);
  const diasRestantes = daysBetween(vencimento, today);
  if (diasRestantes < 0) return 'vencido';
  if (diasRestantes <= 30) return 'vence30';
  if (diasRestantes <= 90) return 'vence90';
  return 'em_dia';
}

// ---- Escopo: tudo que não é o filtro de status ----
// Os cards são calculados sobre o ESCOPO, então mudar de filial ou de departamento
// recalcula os números na hora. O filtro de status só afeta a tabela.
function getScope() {
  const q = state.busca.trim().toLowerCase();
  return state.employees
    .map(f => {
      const status = getStatus(f);
      const vencimento = f.ultimaData ? addMonths(f.ultimaData, f.periodicidade || 12) : null;
      return { ...f, status, vencimento };
    })
    .filter(f => {
      if (q && !f.nome.toLowerCase().includes(q)
        && !(f.matricula || '').toString().includes(state.busca.trim())
        && !(f.cargo || '').toLowerCase().includes(q)) return false;
      if (state.filial !== 'Todas' && filialOf(f) !== state.filial) return false;
      if (state.departamento !== 'Todos' && f.departamento !== state.departamento) return false;
      if (state.setor !== 'Todos' && f.setor !== state.setor) return false;
      if (state.anoVenc !== 'Todos' && (!f.vencimento || f.vencimento.getFullYear() !== Number(state.anoVenc))) return false;
      if (state.mesVenc !== 'Todos' && (!f.vencimento || f.vencimento.getMonth() + 1 !== Number(state.mesVenc))) return false;
      if (state.somenteRevisao && !f.revisaoPendente) return false;
      return true;
    });
}
function scopeLabel() {
  if (state.setor !== 'Todos') return state.setor;
  if (state.departamento !== 'Todos') return state.departamento;
  if (state.filial !== 'Todas') return 'Filial ' + state.filial;
  if (state.isManager) {
    if (state.managerFilial && state.managerFilial !== '*') return 'Filial ' + state.managerFilial;
    if (state.managerDepartamento && state.managerDepartamento !== '*') return state.managerDepartamento;
    if (state.managerSetor && state.managerSetor !== '*') return state.managerSetor;
  }
  return 'Nacional';
}
function countBy(list) {
  return list.reduce((acc, f) => { acc[f.status] = (acc[f.status] || 0) + 1; return acc; }, {});
}
function resumoPorFilial(enriched) {
  const mapa = new Map();
  enriched.forEach(f => {
    const k = filialOf(f);
    if (!mapa.has(k)) mapa.set(k, { filial: k, total: 0, ativos: 0, em_dia: 0, vence90: 0, vence30: 0, vencido: 0, agendado: 0, sem_exame: 0, afastado: 0, inativo: 0 });
    const l = mapa.get(k);
    l.total++; if (f.ativo) l.ativos++; l[f.status]++;
  });
  return Array.from(mapa.values()).sort((a, b) => b.vencido - a.vencido || b.ativos - a.ativos);
}

// Converte os registros do data.json no mesmo formato de "linha de planilha",
// para passar pelo mesmo plano de sincronização (com prévia e preservação do painel).
async function loadSeedRows() {
  const res = await fetch('data.json', { cache: 'no-store' });
  if (!res.ok) throw new Error('Não encontrei o data.json na pasta do painel.');
  const seed = await res.json();
  return seed.map(r => ({
    nome: r.nome, matricula: r.matricula, cargo: r.cargo, filial: r.filial,
    departamento: r.departamento, setor: r.setor, admissao: r.admissao,
    ultimaData: r.ultimaData, demissao: r.afastado ? 'AFASTADO' : '',
  }));
}

async function seedIfEmpty() {
  let snap;
  try { snap = await getDocs(collection(db, EMPLOYEES_COL)); }
  catch (e) { return; } // sem permissão pra listar tudo (ex: gestor) — não faz nada
  if (!snap.empty) return;
  const res = await fetch('data.json');
  const seed = await res.json();
  const CHUNK = 400; // Firestore batch limit is 500 writes
  for (let i = 0; i < seed.length; i += CHUNK) {
    const batch = writeBatch(db);
    seed.slice(i, i + CHUNK).forEach(f => batch.set(doc(db, EMPLOYEES_COL, f.id), f));
    await batch.commit();
  }
}

async function checkManagerStatus() {
  try {
    const snap = await getDoc(doc(db, 'managers', auth.currentUser.email));
    if (snap.exists()) {
      const data = snap.data();
      state.isManager = true;
      state.managerSetor = data.setor || null;
      state.managerDepartamento = data.departamento || null;
      state.managerFilial = data.filial ? normalizeFilial(data.filial) : null;
      if (data.filial === '*') state.managerFilial = '*';
      // gestor de filial já entra com o painel travado na filial dele
      if (state.managerFilial && state.managerFilial !== '*') state.filial = state.managerFilial;
    } else {
      state.isManager = false;
      state.managerSetor = null;
      state.managerDepartamento = null;
      state.managerFilial = null;
    }
  } catch (e) {
    state.isManager = false;
    state.managerSetor = null;
    state.managerDepartamento = null;
    state.managerFilial = null;
  }
}

function listenToEmployees() {
  if (unsubscribeSnapshot) unsubscribeSnapshot();
  const isAllAccess = !state.isManager || state.managerSetor === '*' || state.managerDepartamento === '*' || state.managerFilial === '*';
  let ref;
  if (isAllAccess) {
    ref = collection(db, EMPLOYEES_COL);
  } else if (state.managerFilial) {
    // gestor escopado por filial (ex: "Rio de Janeiro") — vê todos os departamentos dela
    ref = query(collection(db, EMPLOYEES_COL), where('filial', '==', state.managerFilial));
  } else if (state.managerDepartamento) {
    // gestor escopado por departamento (ex: "V.TAL") — vê todos os setores desse departamento
    ref = query(collection(db, EMPLOYEES_COL), where('departamento', '==', state.managerDepartamento));
  } else if (state.managerSetor) {
    // gestor escopado por um único setor específico
    ref = query(collection(db, EMPLOYEES_COL), where('setor', '==', state.managerSetor));
  } else {
    ref = collection(db, EMPLOYEES_COL);
  }
  unsubscribeSnapshot = onSnapshot(ref, (snap) => {
    state.employees = snap.docs.map(d => d.data());
    render();
  }, (err) => {
    showToast('Erro ao conectar ao banco de dados: ' + err.message, true);
  });
  if (!state.isManager) listenToSyncMeta();
}
function listenToSyncMeta() {
  if (unsubscribeSyncMeta) return;
  unsubscribeSyncMeta = onSnapshot(doc(db, META_COL, SYNC_DOC), (snap) => {
    state.syncMeta = snap.exists() ? snap.data() : null;
    render();
  }, () => { /* doc pode não existir ainda — robô não configurado */ });
}

async function saveEmployee(id, data) {
  try { await setDoc(doc(db, EMPLOYEES_COL, id), data, { merge: true }); }
  catch (e) { showToast('Não foi possível salvar: ' + e.message, true); }
}
async function removeEmployee(id) {
  try { await deleteDoc(doc(db, EMPLOYEES_COL, id)); }
  catch (e) { showToast('Não foi possível excluir: ' + e.message, true); }
}

function showToast(msg, isError) {
  const root = document.getElementById('toast-root');
  root.innerHTML = `<div class="toast" style="background:${isError ? '#C4432E' : '#1A1A1A'}">${msg}</div>`;
  setTimeout(() => { root.innerHTML = ''; }, 2800);
}

function updateEmployee(id, patch) {
  const idx = state.employees.findIndex(f => f.id === id);
  if (idx === -1) return;
  const atual = state.employees[idx];
  // Toda vez que a data do exame muda, registra uma entrada no histórico do colaborador
  // (mantém as últimas 20 — histórico é pra consulta, não um arquivo morto crescendo à toa).
  if (patch.ultimaData && patch.ultimaData !== atual.ultimaData) {
    const historico = Array.isArray(atual.historico) ? atual.historico.slice(-19) : [];
    historico.push({ data: patch.ultimaData, registradoEm: new Date().toISOString(), origem: 'manual' });
    patch = { ...patch, historico };
  }
  const updated = { ...atual, ...patch };
  saveEmployee(id, updated); // onSnapshot will re-render once Firestore confirms
}
function addEmployee(data) {
  const id = 'novo_' + Date.now();
  const record = { id, matricula: data.matricula || '', dataAgendada: '', ativo: true, periodicidade: 12, situacao: 'Ativo', ...data };
  saveEmployee(id, record);
  showToast(`${data.nome} adicionado ao controle.`);
}
function deleteEmployee(id) {
  removeEmployee(id);
  showToast('Registro excluído permanentemente.');
}

// Valor comparável de cada coluna ordenável — string p/ texto, Date p/ data.
function sortValue(f, col) {
  switch (col) {
    case 'filial': return filialOf(f);
    case 'nome': return f.nome || '';
    case 'departamento': return f.departamento || '';
    case 'ultimaData': return f.ultimaData ? new Date(f.ultimaData + 'T00:00:00') : new Date(0);
    case 'status': return STATUS_META[f.status] ? STATUS_META[f.status].label : '';
    case 'vencimento':
    default:
      return f.ultimaData ? addMonths(f.ultimaData, f.periodicidade || 12) : new Date(0);
  }
}
function getFiltered() {
  const dir = state.sortDir === 'desc' ? -1 : 1;
  return getScope().filter(f => {
    if (state.status !== 'Todos' && f.status !== state.status) return false;
    return true;
  }).sort((a, b) => {
    const va = sortValue(a, state.sortBy), vb = sortValue(b, state.sortBy);
    if (va instanceof Date || vb instanceof Date) return (va - vb) * dir;
    return va.toString().localeCompare(vb.toString(), 'pt-BR') * dir;
  });
}

function render() {
  const app = document.getElementById('app');
  const scope = getScope();                       // cards e indicadores olham só o escopo
  const ativos = scope.filter(f => f.ativo).length;
  const counts = countBy(scope);
  const filtered = getFiltered();

  // listas em cascata: a filial define os departamentos, o departamento define os setores
  const podeTrocarFilial = !state.isManager || state.managerFilial === '*' || !state.managerFilial;
  const filiais = ['Todas', ...Array.from(new Set(state.employees.map(filialOf))).sort((a, b) => a.localeCompare(b, 'pt-BR'))];
  const naFilial = state.employees.filter(f => state.filial === 'Todas' || filialOf(f) === state.filial);
  const departamentos = ['Todos', ...Array.from(new Set(naFilial.map(f => f.departamento).filter(Boolean))).sort((a, b) => a.localeCompare(b, 'pt-BR'))];
  const noDepto = naFilial.filter(f => state.departamento === 'Todos' || f.departamento === state.departamento);
  const setores = ['Todos', ...Array.from(new Set(noDepto.map(f => f.setor).filter(Boolean))).sort((a, b) => a.localeCompare(b, 'pt-BR'))];
  if (!departamentos.includes(state.departamento)) state.departamento = 'Todos';
  if (!setores.includes(state.setor)) state.setor = 'Todos';
  const anosVenc = ['Todos', ...Array.from(new Set(
    state.employees.filter(f => f.ultimaData).map(f => addMonths(f.ultimaData, f.periodicidade || 12).getFullYear())
  )).sort((a, b) => a - b)];
  const temFiltro = state.filial !== 'Todas' || state.departamento !== 'Todos' || state.setor !== 'Todos' || state.status !== 'Todos' || state.busca
    || state.anoVenc !== 'Todos' || state.mesVenc !== 'Todos';
  const pctEmDia = ativos ? Math.round(((counts.em_dia || 0) / ativos) * 100) : 0;

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  if (state.page > totalPages) state.page = totalPages;
  const pageItems = filtered.slice((state.page - 1) * PAGE_SIZE, state.page * PAGE_SIZE);

  app.innerHTML = `
    <div class="header">
      <div>
        <div class="eyebrow">Controle de Saúde Ocupacional</div>
        <h1 class="display">${state.isManager ? `Painel de Indicadores — ${escapeHtml(scopeLabel())}` : 'Painel de ASOs'}</h1>
        <div class="sub">
          ${scope.length.toLocaleString('pt-BR')} de ${state.employees.length.toLocaleString('pt-BR')} colaborador(es) ·
          <strong>${escapeHtml(scopeLabel())}</strong>${state.isManager ? ' · modo consulta (somente leitura)' : ''}
        </div>
      </div>
      <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap">
        ${state.isManager ? `<button class="btn-secondary" id="btn-export-xlsx">${ICONS.sheet} Baixar indicadores</button>` : `
          <button class="btn-secondary" id="btn-tendencia">${ICONS.sheet} ${state.tendenciaAberta ? 'Ocultar' : 'Ver'} tendência</button>
          <button class="btn-secondary" id="btn-import-sync">${ICONS.upload} Sincronizar base nacional</button>
          <button class="btn-secondary" id="btn-import-new">${ICONS.upload} Importar colaboradores</button>
          <button class="btn-secondary" id="btn-import-dismiss">${ICONS.upload} Importar desligamentos</button>
          <button class="btn-secondary" id="btn-export-xlsx">${ICONS.sheet} Baixar indicadores</button>
          <button class="btn-add" id="btn-add">${ICONS.plus} Novo colaborador</button>
        `}
        <button class="logout-btn" id="btn-logout">Sair (${escapeHtml(auth.currentUser ? auth.currentUser.email : '')})</button>
      </div>
    </div>

    ${!state.isManager ? syncIndicator() : ''}
    ${attentionBanner(counts)}

    <div class="counters">
      ${countCard(`Total ativos${ativos ? ` · ${pctEmDia}% em dia` : ''}`, ativos, 'var(--pine)', null)}
      ${countCard('Em dia', counts.em_dia || 0, 'var(--c-emdia)', 'em_dia')}
      ${countCard('Vence em 90 dias', counts.vence90 || 0, 'var(--c-vence90)', 'vence90')}
      ${countCard('Vence em 30 dias', counts.vence30 || 0, 'var(--c-vence30)', 'vence30')}
      ${countCard('Vencidos', counts.vencido || 0, 'var(--c-vencido)', 'vencido')}
      ${countCard('Agendados', counts.agendado || 0, 'var(--c-agendado)', 'agendado')}
      ${countCard('Sem exame', counts.sem_exame || 0, 'var(--c-semexame)', 'sem_exame')}
      ${countCard('Afastados', counts.afastado || 0, 'var(--c-afastado)', 'afastado')}
      ${countCard('Desligados', counts.inativo || 0, 'var(--c-inativo)', 'inativo')}
      ${revisaoCard(scope)}
    </div>

    ${state.tendenciaAberta ? tendenciaPanel(scope) : ''}

    <div class="toolbar">
      <div class="search-wrap">${ICONS.search}<input id="input-busca" placeholder="Buscar por nome ou matrícula" value="${escapeAttr(state.busca)}"></div>
      <div class="select-wrap">
        <select id="select-filial" ${podeTrocarFilial ? '' : 'disabled title="Seu acesso é restrito a esta filial"'}>
          ${filiais.map(f => `<option value="${escapeAttr(f)}" ${f === state.filial ? 'selected' : ''}>${f === 'Todas' ? 'Todas as filiais' : escapeHtml(f)}</option>`).join('')}
        </select>${ICONS.chevron}
      </div>
      <div class="select-wrap">
        <select id="select-depto">
          ${departamentos.map(d => `<option value="${escapeAttr(d)}" ${d === state.departamento ? 'selected' : ''}>${d === 'Todos' ? 'Todos os departamentos' : d}</option>`).join('')}
        </select>${ICONS.chevron}
      </div>
      <div class="select-wrap">
        <select id="select-setor">
          ${setores.map(s => `<option value="${escapeAttr(s)}" ${s === state.setor ? 'selected' : ''}>${s === 'Todos' ? 'Todos os setores' : escapeHtml(s)}</option>`).join('')}
        </select>${ICONS.chevron}
      </div>
      <div class="select-wrap">
        <select id="select-status">
          <option value="Todos" ${state.status === 'Todos' ? 'selected' : ''}>Todos os status</option>
          ${Object.entries(STATUS_META).map(([k, v]) => `<option value="${k}" ${state.status === k ? 'selected' : ''}>${v.label}</option>`).join('')}
        </select>${ICONS.chevron}
      </div>
      <div class="select-wrap">
        <select id="select-ano-venc">
          <option value="Todos" ${state.anoVenc === 'Todos' ? 'selected' : ''}>Ano de vencimento</option>
          ${anosVenc.filter(a => a !== 'Todos').map(a => `<option value="${a}" ${String(a) === String(state.anoVenc) ? 'selected' : ''}>${a}</option>`).join('')}
        </select>${ICONS.chevron}
      </div>
      <div class="select-wrap">
        <select id="select-mes-venc">
          <option value="Todos" ${state.mesVenc === 'Todos' ? 'selected' : ''}>Mês de vencimento</option>
          ${MESES.map((m, i) => `<option value="${i + 1}" ${String(i + 1) === String(state.mesVenc) ? 'selected' : ''}>${m}</option>`).join('')}
        </select>${ICONS.chevron}
      </div>
      <button class="clear-link" id="btn-por-filial">${state.verPorFilial ? 'Ocultar visão por filial' : 'Ver por filial'}</button>
      ${temFiltro ? `<button class="clear-link" id="btn-clear">Limpar filtros</button>` : ''}
    </div>

    ${state.verPorFilial ? painelPorFilialHtml(getScope()) : ''}

    <div class="result-count">${filtered.length.toLocaleString('pt-BR')} registro(s) encontrado(s)</div>
    ${bulkBarHtml()}

    <div class="table-wrap">
      <div class="table-card">
        <table>
          <thead><tr>
            ${state.isManager ? '' : `<th style="width:34px"><input type="checkbox" id="check-all" ${pageItems.length && pageItems.every(f => state.selecionados.has(f.id)) ? 'checked' : ''}></th>`}
            ${sortableTh('col-filial', 'filial', 'Filial')}
            ${sortableTh('', 'nome', 'Colaborador')}
            ${sortableTh('', 'departamento', 'Departamento')}
            ${sortableTh('', 'ultimaData', 'Última realização')}
            ${sortableTh('', 'vencimento', 'Vencimento')}
            ${sortableTh('', 'status', 'Status')}
            <th>Ações</th>
          </tr></thead>
          <tbody>
            ${pageItems.length === 0 ? `<tr class="empty-row"><td colspan="${state.isManager ? 7 : 8}">Nenhum registro encontrado com os filtros atuais.</td></tr>` : pageItems.map(rowHtml).join('')}
          </tbody>
        </table>
        <div class="pagination">
          <span>Página ${state.page} de ${totalPages}</span>
          <div class="pages">
            <button id="pg-prev" ${state.page === 1 ? 'disabled' : ''}>Anterior</button>
            <button id="pg-next" ${state.page === totalPages ? 'disabled' : ''}>Próxima</button>
          </div>
        </div>
      </div>
    </div>
    <div class="footer-note">Dados salvos automaticamente neste navegador.</div>
  `;

  attachEvents();
}

function painelPorFilialHtml(enriched) {
  const linhas = resumoPorFilial(enriched);
  if (!linhas.length) return '';
  return `
    <div class="filial-panel">
      <div class="filial-panel-head">
        <strong>Visão por filial</strong>
        <span>ordenado por vencidos · clique numa linha para filtrar</span>
      </div>
      <table class="filial-table">
        <thead><tr>
          <th>Filial</th><th>Ativos</th><th>Vencidos</th><th>Vence 30</th><th>Vence 90</th><th>Em dia</th><th>Afastados</th><th>Cobertura</th>
        </tr></thead>
        <tbody>
          ${linhas.map(l => {
            const pct = l.ativos ? Math.round((l.em_dia / l.ativos) * 100) : 0;
            return `<tr class="filial-row" data-filial="${escapeAttr(l.filial)}">
              <td><strong>${escapeHtml(l.filial)}</strong></td>
              <td class="mono">${l.ativos.toLocaleString('pt-BR')}</td>
              <td class="mono" style="color:var(--c-vencido);font-weight:600">${l.vencido.toLocaleString('pt-BR')}</td>
              <td class="mono" style="color:var(--c-vence30)">${l.vence30.toLocaleString('pt-BR')}</td>
              <td class="mono" style="color:var(--c-vence90)">${l.vence90.toLocaleString('pt-BR')}</td>
              <td class="mono" style="color:var(--c-emdia)">${l.em_dia.toLocaleString('pt-BR')}</td>
              <td class="mono" style="color:var(--c-afastado)">${l.afastado.toLocaleString('pt-BR')}</td>
              <td>
                <div class="bar"><div class="bar-fill" style="width:${pct}%"></div></div>
                <span class="bar-lbl mono">${pct}%</span>
              </td>
            </tr>`;
          }).join('')}
        </tbody>
      </table>
    </div>`;
}

function sortableTh(extraClass, col, label) {
  const ativo = state.sortBy === col;
  const seta = ativo ? (state.sortDir === 'asc' ? ' ↑' : ' ↓') : '';
  return `<th class="${extraClass} sortable-th" data-sort="${col}" style="cursor:pointer;user-select:none">${label}${seta}</th>`;
}

function bulkBarHtml() {
  const n = state.selecionados.size;
  if (!n || state.isManager) return '';
  return `
    <div class="bulk-bar">
      <span>${n} selecionado(s)</span>
      <button class="btn-secondary" id="btn-bulk-agendar">${ICONS.calendar} Agendar selecionados</button>
      <button class="btn-secondary" id="btn-bulk-realizar">${ICONS.check} Marcar como realizado</button>
      <button class="clear-link" id="btn-bulk-clear">Limpar seleção</button>
    </div>`;
}

function countCard(label, value, color, statusKey) {
  const active = statusKey && state.status === statusKey;
  return `<div class="count-card ${active ? 'active' : ''}" style="border-top-color:${color}" data-status="${statusKey || ''}">
    <div class="val mono" style="color:${color}">${value.toLocaleString('pt-BR')}</div>
    <div class="lbl">${label}</div>
  </div>`;
}
function revisaoCard(scope) {
  const pendentes = scope.filter(f => f.revisaoPendente).length;
  if (!pendentes && !state.somenteRevisao) return '';
  return `<div class="count-card ${state.somenteRevisao ? 'active' : ''}" style="border-top-color:#B7791E" data-revisao="1">
    <div class="val mono" style="color:#B7791E">${pendentes.toLocaleString('pt-BR')}</div>
    <div class="lbl">Pendente de revisão (robô)</div>
  </div>`;
}
// Banner: chama atenção pra vencidos/vence30 assim que a pessoa entra, sem precisar filtrar antes.
function attentionBanner(counts) {
  const vencidos = counts.vencido || 0;
  const vence30 = counts.vence30 || 0;
  if (!vencidos && !vence30) return '';
  const partes = [];
  if (vencidos) partes.push(`<strong>${vencidos}</strong> vencido${vencidos > 1 ? 's' : ''}`);
  if (vence30) partes.push(`<strong>${vence30}</strong> vencendo em 30 dias`);
  return `
    <div class="attention-banner" id="attention-banner">
      ${ICONS.alert}
      <span>${partes.join(' · ')} — vale conferir antes de seguir com outras tarefas.</span>
      <button class="banner-link" id="banner-ver-vencidos">Ver agora</button>
    </div>`;
}
function syncIndicator() {
  const meta = state.syncMeta;
  if (!meta) {
    return `<div class="sync-indicator sync-off">${ICONS.rotate} Robô de sincronização automática ainda não configurado</div>`;
  }
  const quando = fmtDateTime(meta.lastRun);
  const pend = meta.pendentes || 0;
  return `<div class="sync-indicator sync-on">
    ${ICONS.rotate} Última sincronização automática: ${quando || '—'}
    ${pend ? `<span class="sync-pend">· ${pend} pendente${pend > 1 ? 's' : ''} de revisão</span>` : ''}
  </div>`;
}
// Distribui os vencimentos dos próximos 6 meses (a partir do mês atual) — não é
// histórico (não guardamos snapshots diários), é a projeção do que está por vir,
// pra você enxergar se um mês específico vai concentrar muito trabalho.
function tendenciaPanel(scope) {
  const hoje = new Date();
  const meses = [];
  for (let i = 0; i < 6; i++) {
    const d = new Date(hoje.getFullYear(), hoje.getMonth() + i, 1);
    meses.push({ ano: d.getFullYear(), mes: d.getMonth(), label: d.toLocaleDateString('pt-BR', { month: 'short' }).replace('.', ''), count: 0 });
  }
  scope.forEach(f => {
    if (!f.vencimento) return;
    const v = f.vencimento;
    const idx = meses.findIndex(m => m.ano === v.getFullYear() && m.mes === v.getMonth());
    if (idx !== -1) meses[idx].count++;
  });
  const max = Math.max(1, ...meses.map(m => m.count));
  const barMax = 90;
  return `
    <div class="filial-panel">
      <div class="filial-panel-head">
        <strong>Vencimentos por mês (próximos 6 meses)</strong>
        <span>Projeção com base nas datas de vencimento atuais — não é histórico</span>
      </div>
      <div style="display:flex;gap:22px;align-items:flex-end;padding:20px 24px 24px;overflow-x:auto">
        ${meses.map(m => `
          <div style="display:flex;flex-direction:column;align-items:center;gap:8px;min-width:52px">
            <div class="mono" style="font-size:12.5px;color:${m.count > 0 ? 'var(--c-vence30)' : 'var(--muted)'};font-weight:600">${m.count}</div>
            <div style="width:32px;height:${barMax}px;background:#EEF1F0;border-radius:6px;display:flex;align-items:flex-end;overflow:hidden">
              <div style="width:100%;height:${Math.round((m.count / max) * barMax)}px;background:${m.count > 0 ? 'var(--c-vence30)' : '#DCDCDC'};border-radius:6px 6px 0 0"></div>
            </div>
            <div style="font-size:12px;color:var(--muted);text-transform:capitalize">${m.label}</div>
          </div>`).join('')}
      </div>
    </div>`;
}

function rowHtml(f) {
  const meta = STATUS_META[f.status];
  const vencimento = f.ultimaData ? addMonths(f.ultimaData, f.periodicidade || 12) : null;
  return `
    <tr style="border-left-color:${meta.color}">
      ${state.isManager ? '' : `<td><input type="checkbox" class="row-check" data-id="${f.id}" ${state.selecionados.has(f.id) ? 'checked' : ''}></td>`}
      <td class="col-filial"><span class="filial-tag" data-filial="${escapeAttr(filialOf(f))}">${escapeHtml(filialOf(f))}</span></td>
      <td class="name-cell">
        <div class="name">${escapeHtml(f.nome)}</div>
        <div class="meta mono">Matr. ${escapeHtml(f.matricula || '—')} · ${escapeHtml(f.cargo || '')}</div>
      </td>
      <td>${escapeHtml(f.departamento || '—')}${f.setor ? `<div class="meta" style="font-size:11.5px;color:#8A9793">${escapeHtml(f.setor)}</div>` : ''}</td>
      <td class="mono">
        ${fmt(f.ultimaData)}
        ${Array.isArray(f.historico) && f.historico.length ? `<button class="hist-link" data-id="${f.id}" title="Ver histórico de exames">${ICONS.clock || '↻'}</button>` : ''}
      </td>
      <td class="mono">
        ${vencimento ? fmt(vencimento) : '—'}
        ${f.dataAgendada && f.status === 'agendado' ? `<div class="sched-note">agendado: ${fmt(f.dataAgendada)}</div>` : ''}
        ${f.status === 'afastado' ? `<div class="afastado-note">afastado desde ${fmt(f.dataAfastamento)}${f.dataRetorno ? ' · retorno previsto ' + fmt(f.dataRetorno) : ''}</div>` : ''}
      </td>
      <td><span class="badge" style="background:${meta.bg};color:${meta.color}">${meta.label}</span></td>
      <td>
        <div class="row-actions">
          ${!state.isManager && f.ultimoAsoPath ? `<button class="icon-btn" title="Ver ASO" data-action="ver-aso" data-id="${f.id}" data-matricula="${escapeAttr(f.matricula || f.id)}">${ICONS.eye}</button>` : ''}
          ${state.isManager ? '<span style="color:#8A9793;font-size:12px">—</span>' : (f.ativo ? (f.afastado ? `
            <button class="icon-btn" title="Editar" data-action="edit" data-id="${f.id}">${ICONS.edit}</button>
            <button class="icon-btn" title="Registrar retorno" data-action="retornar" data-id="${f.id}">${ICONS.rotate}</button>
            <button class="icon-btn" title="Desligado" data-action="desligar" data-id="${f.id}">${ICONS.userx}</button>
          ` : `
            <button class="icon-btn" title="Marcar como agendado" data-action="agendar" data-id="${f.id}">${ICONS.calendar}</button>
            <button class="icon-btn" title="Marcar como realizado" data-action="realizar" data-id="${f.id}">${ICONS.check}</button>
            <button class="icon-btn" title="Editar" data-action="edit" data-id="${f.id}">${ICONS.edit}</button>
            <button class="icon-btn" title="Afastar (licença/afastamento)" data-action="afastar" data-id="${f.id}">${ICONS.pause}</button>
            <button class="icon-btn" title="Desligado" data-action="desligar" data-id="${f.id}">${ICONS.userx}</button>
          `) : `<button class="icon-btn" title="Reativar" data-action="reativar" data-id="${f.id}">${ICONS.usercheck}</button>`)}
          ${state.isManager ? '' : `<button class="icon-btn" title="Excluir permanentemente" data-action="delete" data-id="${f.id}">${ICONS.trash}</button>`}
        </div>
      </td>
    </tr>`;
}

function escapeHtml(s) { return (s || '').toString().replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function escapeAttr(s) { return escapeHtml(s); }

function attachEvents() {
  const btnAdd = document.getElementById('btn-add');
  if (btnAdd) btnAdd.onclick = () => openModal('add');
  const btnImportNew = document.getElementById('btn-import-new');
  if (btnImportNew) btnImportNew.onclick = () => openModal('import-new');
  const btnSync = document.getElementById('btn-import-sync');
  if (btnSync) btnSync.onclick = () => openModal('import-sync');
  const btnImportDismiss = document.getElementById('btn-import-dismiss');
  if (btnImportDismiss) btnImportDismiss.onclick = () => openModal('import-dismiss');
  const btnExport = document.getElementById('btn-export-xlsx');
  if (btnExport) btnExport.onclick = exportIndicatorsXlsx;
  document.getElementById('btn-logout').onclick = () => signOut(auth);
  document.getElementById('input-busca').oninput = (e) => {
    clearTimeout(buscaDebounceTimer);
    buscaDebounceTimer = setTimeout(() => {
      state.busca = e.target.value;
      state.page = 1;
      const cursorPos = e.target.selectionStart;
      render();
      const input = document.getElementById('input-busca');
      input.focus();
      input.setSelectionRange(cursorPos, cursorPos);
    }, 300);
  };
  const selFilial = document.getElementById('select-filial');
  if (selFilial) selFilial.onchange = (e) => {
    state.filial = e.target.value;
    state.departamento = 'Todos'; state.setor = 'Todos'; // recomeça a cascata
    state.page = 1; render();
  };
  document.getElementById('select-depto').onchange = (e) => { state.departamento = e.target.value; state.setor = 'Todos'; state.page = 1; render(); };
  document.getElementById('select-setor').onchange = (e) => { state.setor = e.target.value; state.page = 1; render(); };
  document.getElementById('select-status').onchange = (e) => { state.status = e.target.value; state.page = 1; render(); };
  document.getElementById('select-ano-venc').onchange = (e) => { state.anoVenc = e.target.value; state.page = 1; render(); };
  document.getElementById('select-mes-venc').onchange = (e) => { state.mesVenc = e.target.value; state.page = 1; render(); };
  const btnPorFilial = document.getElementById('btn-por-filial');
  if (btnPorFilial) btnPorFilial.onclick = () => { state.verPorFilial = !state.verPorFilial; render(); };
  const clearBtn = document.getElementById('btn-clear');
  if (clearBtn) clearBtn.onclick = () => {
    state.busca = ''; state.status = 'Todos'; state.departamento = 'Todos'; state.setor = 'Todos';
    state.anoVenc = 'Todos'; state.mesVenc = 'Todos';
    if (!state.isManager || state.managerFilial === '*' || !state.managerFilial) state.filial = 'Todas';
    state.page = 1; render();
  };

  document.querySelectorAll('.filial-row, .filial-tag').forEach(el => {
    el.onclick = (ev) => {
      if (!(!state.isManager || state.managerFilial === '*' || !state.managerFilial)) return;
      ev.stopPropagation();
      state.filial = el.dataset.filial;
      state.departamento = 'Todos'; state.setor = 'Todos'; state.page = 1;
      render();
    };
  });

  document.querySelectorAll('.count-card').forEach(el => {
    el.onclick = () => {
      if (el.dataset.revisao) { state.somenteRevisao = !state.somenteRevisao; state.page = 1; render(); return; }
      state.status = el.dataset.status || 'Todos'; state.page = 1; render();
    };
  });
  const bannerBtn = document.getElementById('banner-ver-vencidos');
  if (bannerBtn) bannerBtn.onclick = () => { state.status = counts.vencido ? 'vencido' : 'vence30'; state.page = 1; render(); };
  document.querySelectorAll('.hist-link').forEach(btn => {
    btn.onclick = (e) => {
      e.stopPropagation();
      const f = state.employees.find(x => x.id === btn.dataset.id);
      if (f) openModal('historico', f);
    };
  });
  const btnTendencia = document.getElementById('btn-tendencia');
  if (btnTendencia) btnTendencia.onclick = () => { state.tendenciaAberta = !state.tendenciaAberta; render(); };
  const prev = document.getElementById('pg-prev'), next = document.getElementById('pg-next');
  if (prev) prev.onclick = () => { state.page--; render(); };
  if (next) next.onclick = () => { state.page++; render(); };

  document.querySelectorAll('.sortable-th').forEach(th => {
    th.onclick = () => {
      const col = th.dataset.sort;
      if (state.sortBy === col) state.sortDir = state.sortDir === 'asc' ? 'desc' : 'asc';
      else { state.sortBy = col; state.sortDir = 'asc'; }
      render();
    };
  });

  const checkAll = document.getElementById('check-all');
  if (checkAll) checkAll.onchange = () => {
    document.querySelectorAll('.row-check').forEach(cb => {
      if (checkAll.checked) state.selecionados.add(cb.dataset.id);
      else state.selecionados.delete(cb.dataset.id);
    });
    render();
  };
  document.querySelectorAll('.row-check').forEach(cb => {
    cb.onclick = (ev) => {
      ev.stopPropagation();
      if (cb.checked) state.selecionados.add(cb.dataset.id); else state.selecionados.delete(cb.dataset.id);
      render();
    };
  });
  const btnBulkClear = document.getElementById('btn-bulk-clear');
  if (btnBulkClear) btnBulkClear.onclick = () => { state.selecionados.clear(); render(); };
  const btnBulkAgendar = document.getElementById('btn-bulk-agendar');
  if (btnBulkAgendar) btnBulkAgendar.onclick = () => openBulkModal('agendar');
  const btnBulkRealizar = document.getElementById('btn-bulk-realizar');
  if (btnBulkRealizar) btnBulkRealizar.onclick = () => openBulkModal('realizar');

  document.querySelectorAll('[data-action]').forEach(btn => {
    btn.onclick = () => {
      const id = btn.dataset.id;
      const action = btn.dataset.action;
      const f = state.employees.find(e => e.id === id);
      if (action === 'agendar') openModal('agendar', f);
      else if (action === 'realizar') openModal('realizar', f);
      else if (action === 'edit') openModal('edit', f);
      else if (action === 'delete') openModal('delete', f);
      else if (action === 'afastar') openModal('afastar', f);
      else if (action === 'retornar') openModal('retornar', f);
      else if (action === 'desligar') updateEmployee(id, { ativo: false, afastado: false, dataAgendada: '' });
      else if (action === 'reativar') updateEmployee(id, { ativo: true });
      else if (action === 'ver-aso') viewAso(btn.dataset.matricula);
    };
  });
}

const TITLES = {
  add: 'Novo colaborador', edit: 'Editar colaborador',
  agendar: 'Marcar exame como agendado', realizar: 'Registrar exame realizado',
  afastar: 'Registrar afastamento', retornar: 'Registrar retorno',
  delete: 'Excluir registro permanentemente',
  'import-new': 'Importar novos colaboradores', 'import-dismiss': 'Importar desligamentos em lote',
  'import-sync': 'Sincronizar base nacional',
  'bulk-agendar': 'Agendar exame para vários colaboradores', 'bulk-realizar': 'Registrar exame realizado em massa',
  historico: 'Histórico de exames',
};

// Grava várias atualizações de uma vez (mesmo campo para todos os selecionados),
// em lotes de até 400 — mesmo limite do Firestore usado no resto do app.
async function bulkUpdateEmployees(ids, patch, onProgress) {
  const CHUNK = 400;
  for (let i = 0; i < ids.length; i += CHUNK) {
    const batch = writeBatch(db);
    ids.slice(i, i + CHUNK).forEach(id => batch.set(doc(db, EMPLOYEES_COL, id), patch, { merge: true }));
    await batch.commit();
    if (onProgress) onProgress(Math.min(i + CHUNK, ids.length), ids.length);
  }
}

function openBulkModal(type) {
  const ids = Array.from(state.selecionados);
  const root = document.getElementById('modal-root');
  root.innerHTML = `
    <div class="overlay" id="overlay">
      <div class="modal-box">
        <div class="modal-head"><h3 class="display">${TITLES['bulk-' + type]}</h3><button class="icon-btn" id="modal-close">${ICONS.x}</button></div>
        <div id="modal-body"></div>
      </div>
    </div>`;
  document.getElementById('overlay').onclick = (e) => { if (e.target.id === 'overlay') closeModal(); };
  document.getElementById('modal-close').onclick = closeModal;
  const body = document.getElementById('modal-body');
  const corBtn = type === 'agendar' ? '#2E6E8E' : '#2F9E62';
  body.innerHTML = `
    <p style="font-size:14px;color:var(--muted);margin-top:0">Aplicar a mesma data para os <strong>${ids.length}</strong> colaborador(es) selecionado(s).</p>
    <label class="field-label">${type === 'agendar' ? 'Data agendada' : 'Data de realização'}</label>
    <input type="date" class="field-input" id="f-bulk-data">
    <button class="modal-primary" style="background:${corBtn}" id="modal-save">Aplicar a ${ids.length} colaborador(es)</button>
    <div id="bulk-progress" style="display:none;margin-top:14px">
      <div class="bar" style="width:100%"><div class="bar-fill" id="bulk-progress-fill" style="width:0%"></div></div>
      <div class="bar-lbl mono" id="bulk-progress-lbl" style="margin-left:0;margin-top:6px;display:block"></div>
    </div>`;
  document.getElementById('modal-save').onclick = async () => {
    const val = document.getElementById('f-bulk-data').value;
    if (!val) { showToast('Escolha uma data.', true); return; }
    const saveBtn = document.getElementById('modal-save');
    saveBtn.disabled = true;
    document.getElementById('bulk-progress').style.display = 'block';
    const fill = document.getElementById('bulk-progress-fill');
    const lbl = document.getElementById('bulk-progress-lbl');
    const patch = type === 'agendar' ? { dataAgendada: val } : { ultimaData: val, dataAgendada: '' };
    try {
      await bulkUpdateEmployees(ids, patch, (done, total) => {
        fill.style.width = Math.round((done / total) * 100) + '%';
        lbl.textContent = `${done.toLocaleString('pt-BR')} de ${total.toLocaleString('pt-BR')}`;
      });
      state.selecionados.clear();
      closeModal();
      showToast(`${ids.length} colaborador(es) atualizado(s).`);
    } catch (e) {
      showToast('Não foi possível concluir: ' + e.message, true);
      saveBtn.disabled = false;
    }
  };
}

function openModal(type, f) {
  const root = document.getElementById('modal-root');
  const isForm = type === 'add' || type === 'edit';
  root.innerHTML = `
    <div class="overlay" id="overlay">
      <div class="modal-box">
        <div class="modal-head"><h3 class="display">${TITLES[type]}</h3><button class="icon-btn" id="modal-close">${ICONS.x}</button></div>
        <div id="modal-body"></div>
      </div>
    </div>`;
  document.getElementById('overlay').onclick = (e) => { if (e.target.id === 'overlay') closeModal(); };
  document.getElementById('modal-close').onclick = closeModal;

  const body = document.getElementById('modal-body');
  if (isForm) {
    const d = f || { nome: '', matricula: '', cargo: '', filial: '', departamento: '', setor: '', ultimaData: '', periodicidade: 12 };
    const filiaisConhecidas = Array.from(new Set([...Object.values(FILIAL_MAP), ...state.employees.map(filialOf)])).sort((a, b) => a.localeCompare(b, 'pt-BR'));
    body.innerHTML = `
      <label class="field-label">Nome completo</label><input class="field-input" id="f-nome" value="${escapeAttr(d.nome)}">
      <label class="field-label">Matrícula</label><input class="field-input" id="f-matricula" value="${escapeAttr(d.matricula)}">
      <label class="field-label">Cargo</label><input class="field-input" id="f-cargo" value="${escapeAttr(d.cargo)}">
      <label class="field-label">Filial</label>
      <input class="field-input" id="f-filial" list="lista-filiais" placeholder="Ex.: Osasco" value="${escapeAttr(d.filial || '')}">
      <datalist id="lista-filiais">${filiaisConhecidas.map(x => `<option value="${escapeAttr(x)}"></option>`).join('')}</datalist>
      <label class="field-label">Departamento</label><input class="field-input" id="f-departamento" value="${escapeAttr(d.departamento)}">
      <label class="field-label">Setor</label><input class="field-input" id="f-setor" value="${escapeAttr(d.setor)}">
      <label class="field-label">Data da última realização</label><input type="date" class="field-input" id="f-ultimaData" value="${d.ultimaData || ''}">
      <label class="field-label">Periodicidade (meses)</label><input type="number" class="field-input" id="f-periodicidade" value="${d.periodicidade || 12}">
      <button class="modal-primary" style="background:#1A1A1A" id="modal-save">${type === 'add' ? 'Adicionar colaborador' : 'Salvar alterações'}</button>
    `;
    document.getElementById('modal-save').onclick = () => {
      const data = {
        nome: document.getElementById('f-nome').value.trim(),
        matricula: document.getElementById('f-matricula').value.trim(),
        cargo: document.getElementById('f-cargo').value.trim(),
        filial: document.getElementById('f-filial').value.trim() || SEM_FILIAL,
        departamento: document.getElementById('f-departamento').value.trim(),
        setor: document.getElementById('f-setor').value.trim(),
        ultimaData: document.getElementById('f-ultimaData').value,
        periodicidade: Number(document.getElementById('f-periodicidade').value) || 12,
      };
      if (!data.nome || !data.ultimaData) { showToast('Preencha nome e data da última realização.', true); return; }
      if (type === 'add') addEmployee(data); else updateEmployee(f.id, data);
      closeModal();
      showToast(type === 'add' ? undefined : 'Registro atualizado.');
    };
  } else if (type === 'agendar') {
    body.innerHTML = `
      <p style="font-size:14px;color:var(--muted);margin-top:0">Informe a data agendada para o exame de <strong>${escapeHtml(f.nome)}</strong>.</p>
      <label class="field-label">Data agendada</label><input type="date" class="field-input" id="f-data">
      <button class="modal-primary" style="background:#2E6E8E" id="modal-save">Confirmar agendamento</button>`;
    document.getElementById('modal-save').onclick = () => {
      const val = document.getElementById('f-data').value;
      if (!val) { showToast('Escolha uma data.', true); return; }
      updateEmployee(f.id, { dataAgendada: val });
      closeModal(); showToast('Exame agendado.');
    };
  } else if (type === 'realizar') {
    body.innerHTML = `
      <p style="font-size:14px;color:var(--muted);margin-top:0">Informe a data em que o exame de <strong>${escapeHtml(f.nome)}</strong> foi realizado. O vencimento será recalculado automaticamente.</p>
      <label class="field-label">Data de realização</label><input type="date" class="field-input" id="f-data">
      <button class="modal-primary" style="background:#2F9E62" id="modal-save">Confirmar realização</button>`;
    document.getElementById('modal-save').onclick = () => {
      const val = document.getElementById('f-data').value;
      if (!val) { showToast('Escolha uma data.', true); return; }
      updateEmployee(f.id, { ultimaData: val, dataAgendada: '' });
      closeModal(); showToast('Exame registrado como realizado.');
    };
  } else if (type === 'historico') {
    const itens = [...(f.historico || [])].sort((a, b) => (b.data || '').localeCompare(a.data || ''));
    body.innerHTML = `
      <p style="font-size:13.5px;color:var(--muted);margin-top:0">Exames de <strong>${escapeHtml(f.nome)}</strong>, mais recente primeiro.</p>
      <ul class="hist-timeline">
        ${itens.map(h => `<li>
          <span class="hist-dot ${h.origem === 'robô' ? 'robo' : ''}"></span>
          <span><strong>${fmt(h.data)}</strong><br><span style="color:var(--muted);font-size:12px">${h.origem === 'robô' ? 'Lançado automaticamente pelo robô' : 'Lançado manualmente'}</span></span>
        </li>`).join('') || '<li style="color:var(--muted)">Nenhum histórico registrado ainda.</li>'}
      </ul>`;
  } else if (type === 'afastar') {
    body.innerHTML = `
      <p style="font-size:14px;color:var(--muted);margin-top:0">Registre o afastamento de <strong>${escapeHtml(f.nome)}</strong> (licença médica, INSS, etc). O colaborador continua ativo, mas fica marcado como afastado até o retorno.</p>
      <label class="field-label">Data de afastamento</label><input type="date" class="field-input" id="f-afastamento" value="${f.dataAfastamento || ''}">
      <label class="field-label">Data prevista de retorno (opcional)</label><input type="date" class="field-input" id="f-retorno" value="${f.dataRetorno || ''}">
      <button class="modal-primary" style="background:#A6631B" id="modal-save">Confirmar afastamento</button>`;
    document.getElementById('modal-save').onclick = () => {
      const inicio = document.getElementById('f-afastamento').value;
      const previsto = document.getElementById('f-retorno').value;
      if (!inicio) { showToast('Informe a data de afastamento.', true); return; }
      updateEmployee(f.id, { afastado: true, dataAfastamento: inicio, dataRetorno: previsto || '' });
      closeModal(); showToast('Afastamento registrado.');
    };
  } else if (type === 'retornar') {
    body.innerHTML = `
      <p style="font-size:14px;color:var(--muted);margin-top:0">Confirme o retorno de <strong>${escapeHtml(f.nome)}</strong> ao trabalho.</p>
      <label class="field-label">Data de retorno</label><input type="date" class="field-input" id="f-data" value="${f.dataRetorno || new Date().toISOString().slice(0, 10)}">
      <button class="modal-primary" style="background:#2F9E62" id="modal-save">Confirmar retorno</button>`;
    document.getElementById('modal-save').onclick = () => {
      const val = document.getElementById('f-data').value;
      if (!val) { showToast('Escolha uma data.', true); return; }
      updateEmployee(f.id, { afastado: false, dataRetorno: val });
      closeModal(); showToast('Retorno registrado.');
    };
  } else if (type === 'delete') {
    body.innerHTML = `
      <div class="warn-box">${ICONS.alert}<p>Isso removerá <strong>${escapeHtml(f.nome)}</strong> e todo o histórico permanentemente. Se o colaborador foi apenas desligado, prefira "Desligado" para manter o histórico.</p></div>
      <button class="modal-primary" style="background:#C4432E" id="modal-save">Excluir permanentemente</button>`;
    document.getElementById('modal-save').onclick = () => { deleteEmployee(f.id); closeModal(); };
  } else if (type === 'import-sync') {
    body.innerHTML = `
      <p style="font-size:13.5px;color:var(--muted);margin-top:0">
        Envie a planilha nacional do RH (a mesma exportação de sempre). O painel compara com o que já está no banco e mostra o impacto <strong>antes</strong> de gravar qualquer coisa.
      </p>
      <div class="mono" style="font-size:11.5px;background:#F7F9F8;padding:10px;border-radius:6px;margin-bottom:12px;overflow-x:auto">
        Nome_estabelecimento | Nome_depart | Nome_setor | DATA_EXAME_MEDICO | COD.FUN | NOME FUNC. | ADMISSAO | DEMISSAO | DESCR.NIV.CARG.
      </div>
      <p style="font-size:12.5px;color:var(--muted);margin-top:0">
        A planilha atualiza o <strong>cadastro</strong> (nome, cargo, filial, departamento, setor, admissão). O painel mantém o <strong>acompanhamento</strong>: agendamentos e exames lançados aqui não voltam atrás — se a data do painel for mais recente que a da planilha, ela é preservada.
      </p>
      <input type="file" id="import-file-input" accept=".xlsx,.xls,.csv" class="field-input" style="padding:8px">
      <div style="display:flex;align-items:center;gap:10px;margin:2px 0 10px">
        <div style="flex:1;height:1px;background:var(--border)"></div>
        <span style="font-size:12px;color:var(--muted)">ou</span>
        <div style="flex:1;height:1px;background:var(--border)"></div>
      </div>
      <button class="btn-secondary" id="btn-usar-seed" style="width:100%;justify-content:center;background:#EEF1F0;color:var(--text);border:1px solid var(--border)">
        Usar a base nacional já preparada (data.json)
      </button>
      <div id="import-preview" style="font-size:13px;color:var(--muted);min-height:20px;margin:10px 0"></div>
      <label style="display:flex;gap:8px;align-items:flex-start;font-size:13px;margin-bottom:8px">
        <input type="checkbox" id="opt-afast" checked style="margin-top:2px">
        <span>Atualizar afastamentos pela coluna DEMISSAO (quem saiu de "AFASTADO" volta a ativo)</span>
      </label>
      <label style="display:flex;gap:8px;align-items:flex-start;font-size:13px;margin-bottom:14px">
        <input type="checkbox" id="opt-ausentes" style="margin-top:2px">
        <span>Marcar como <strong>desligado</strong> quem está no painel e não aparece na planilha <em id="ausentes-hint"></em></span>
      </label>
      <button class="modal-primary" style="background:#1A1A1A" id="modal-save" disabled>Sincronizar</button>
      <div id="sync-progress" style="display:none;margin-top:14px">
        <div class="bar" style="width:100%"><div class="bar-fill" id="sync-progress-fill" style="width:0%"></div></div>
        <div class="bar-lbl mono" id="sync-progress-lbl" style="margin-left:0;margin-top:6px;display:block"></div>
      </div>
    `;
    const fileInput = document.getElementById('import-file-input');
    const seedBtn = document.getElementById('btn-usar-seed');
    const preview = document.getElementById('import-preview');
    const saveBtn = document.getElementById('modal-save');
    let plan = null;

    const mostrarPrevia = (rows) => {
      plan = buildSyncPlan(rows, state.employees);
      document.getElementById('ausentes-hint').textContent = `(${plan.ausentes.length})`;
      preview.innerHTML = `
        <div style="background:#F7F9F8;border-radius:8px;padding:10px;line-height:1.7">
          <strong>${rows.length.toLocaleString('pt-BR')}</strong> linha(s) lidas<br>
          <span style="color:var(--c-emdia)">+ ${plan.novos.length.toLocaleString('pt-BR')} novo(s) colaborador(es)</span><br>
          <span style="color:var(--c-agendado)">↻ ${plan.atualizados.length.toLocaleString('pt-BR')} atualizado(s)</span><br>
          <span style="color:var(--muted)">= ${plan.semMudanca.length.toLocaleString('pt-BR')} sem alteração</span><br>
          <span style="color:var(--c-afastado)">⚠ ${plan.ausentes.length.toLocaleString('pt-BR')} no painel e fora da base</span>
          ${plan.revisar.length ? `<br><span style="color:var(--c-vencido)">${plan.revisar.length} linha(s) para revisar: ${escapeHtml(plan.revisar.slice(0, 3).join(' · '))}${plan.revisar.length > 3 ? '…' : ''}</span>` : ''}
        </div>`;
      saveBtn.disabled = (plan.novos.length + plan.atualizados.length) === 0;
    };

    fileInput.onchange = async () => {
      const file = fileInput.files[0];
      if (!file) return;
      preview.textContent = 'Lendo planilha…';
      saveBtn.disabled = true; plan = null;
      try {
        mostrarPrevia(await parseSpreadsheet(file));
      } catch (e) {
        preview.innerHTML = `<span style="color:var(--c-vencido)">${escapeHtml(e.message)}</span>`;
      }
    };

    seedBtn.onclick = async () => {
      preview.textContent = 'Lendo a base nacional…';
      saveBtn.disabled = true; plan = null;
      try {
        mostrarPrevia(await loadSeedRows());
      } catch (e) {
        preview.innerHTML = `<span style="color:var(--c-vencido)">${escapeHtml(e.message)}</span>`;
      }
    };

    saveBtn.onclick = async () => {
      if (!plan) return;
      saveBtn.disabled = true; saveBtn.textContent = 'Sincronizando…';
      document.getElementById('sync-progress').style.display = 'block';
      const fill = document.getElementById('sync-progress-fill');
      const lbl = document.getElementById('sync-progress-lbl');
      try {
        const total = await applySync(plan, {
          sincronizarAfastamentos: document.getElementById('opt-afast').checked,
          desligarAusentes: document.getElementById('opt-ausentes').checked,
        }, (done, totalWrites) => {
          fill.style.width = Math.round((done / totalWrites) * 100) + '%';
          lbl.textContent = `Gravando ${done.toLocaleString('pt-BR')} de ${totalWrites.toLocaleString('pt-BR')}`;
        });
        closeModal();
        showToast(`Base sincronizada — ${total.toLocaleString('pt-BR')} registro(s) gravado(s).`);
      } catch (e) {
        showToast('Não foi possível sincronizar: ' + e.message, true);
        saveBtn.disabled = false; saveBtn.textContent = 'Sincronizar';
      }
    };
  } else if (type === 'import-new' || type === 'import-dismiss') {
    const isNew = type === 'import-new';
    body.innerHTML = `
      <p style="font-size:13.5px;color:var(--muted);margin-top:0">
        ${isNew
          ? 'Envie uma planilha (.xlsx ou .csv) com uma linha por colaborador. Colunas aceitas no cabeçalho:'
          : 'Envie uma planilha (.xlsx ou .csv) com os colaboradores desligados. Eles serão marcados como <strong>desligados</strong> (o histórico é mantido — nada é excluído). Coluna aceita no cabeçalho:'}
      </p>
      <div class="mono" style="font-size:12px;background:#F7F9F8;padding:10px;border-radius:6px;margin-bottom:12px;overflow-x:auto">
        ${isNew ? 'nome | matricula | cargo | filial | departamento | setor | ultimaData | periodicidade' : 'matricula (ou nome, se não tiver matrícula)'}
      </div>
      <p style="font-size:12.5px;color:var(--muted)">
        ${isNew
          ? '<strong>nome</strong> é obrigatório e <strong>matricula</strong> é o que evita duplicidade (data no formato dd/mm/aaaa). Sem <strong>ultimaData</strong> o colaborador entra como "Sem exame". <strong>periodicidade</strong> em meses — se vazio, assume 12. Se a matrícula já existir, o colaborador é atualizado em vez de duplicado. Para a planilha completa do RH, use "Sincronizar base nacional".'
          : 'Usamos a <strong>matrícula</strong> para encontrar o colaborador certo (mais confiável que o nome). Quem não for encontrado aparece listado abaixo pra você conferir.'}
      </p>
      <input type="file" id="import-file-input" accept=".xlsx,.xls,.csv" class="field-input" style="padding:8px">
      <div id="import-preview" style="font-size:13px;color:var(--muted);min-height:20px;margin:4px 0 14px"></div>
      <button class="modal-primary" style="background:#1A1A1A" id="modal-save" disabled>${isNew ? 'Importar colaboradores' : 'Confirmar desligamentos'}</button>
      <div id="import-progress" style="display:none;margin-top:14px">
        <div class="bar" style="width:100%"><div class="bar-fill" id="import-progress-fill" style="width:0%"></div></div>
        <div class="bar-lbl mono" id="import-progress-lbl" style="margin-left:0;margin-top:6px;display:block"></div>
      </div>
    `;
    const fileInput = document.getElementById('import-file-input');
    const preview = document.getElementById('import-preview');
    const saveBtn = document.getElementById('modal-save');
    let ready = null;

    fileInput.onchange = async () => {
      const file = fileInput.files[0];
      if (!file) return;
      preview.textContent = 'Lendo planilha…';
      saveBtn.disabled = true;
      ready = null;
      try {
        const rows = await parseSpreadsheet(file);
        if (isNew) {
          const { valid, errors } = buildNewEmployeesFromRows(rows);
          ready = valid;
          preview.innerHTML = `${valid.length} colaborador(es) prontos para importar.` +
            (errors.length ? `<br><span style="color:var(--c-vencido)">${errors.length} linha(s) ignorada(s) por falta de nome: ${escapeHtml(errors.slice(0, 5).join(', '))}${errors.length > 5 ? '…' : ''}</span>` : '');
        } else {
          const { matched, notFound } = buildDismissalsFromRows(rows, state.employees);
          ready = matched;
          preview.innerHTML = `${matched.length} colaborador(es) serão marcados como desligados.` +
            (notFound.length ? `<br><span style="color:var(--c-vencido)">${notFound.length} não encontrado(s) ou já desligado(s): ${escapeHtml(notFound.slice(0, 5).join(', '))}${notFound.length > 5 ? '…' : ''}</span>` : '');
        }
        saveBtn.disabled = !ready || ready.length === 0;
      } catch (e) {
        preview.innerHTML = `<span style="color:var(--c-vencido)">${escapeHtml(e.message)}</span>`;
      }
    };

    saveBtn.onclick = async () => {
      if (!ready || !ready.length) return;
      saveBtn.disabled = true;
      saveBtn.textContent = 'Importando…';
      document.getElementById('import-progress').style.display = 'block';
      const fill = document.getElementById('import-progress-fill');
      const lbl = document.getElementById('import-progress-lbl');
      const onProgress = (done, total) => {
        fill.style.width = Math.round((done / total) * 100) + '%';
        lbl.textContent = `${done.toLocaleString('pt-BR')} de ${total.toLocaleString('pt-BR')}`;
      };
      try {
        if (isNew) { await bulkImportNew(ready, onProgress); showToast(`${ready.length} colaborador(es) importado(s).`); }
        else { await bulkDismiss(ready, onProgress); showToast(`${ready.length} colaborador(es) marcado(s) como desligados.`); }
        closeModal();
      } catch (e) {
        showToast('Não foi possível concluir a importação: ' + e.message, true);
        saveBtn.disabled = false;
        saveBtn.textContent = isNew ? 'Importar colaboradores' : 'Confirmar desligamentos';
      }
    };
  }
}
function closeModal() { document.getElementById('modal-root').innerHTML = ''; }

// Abre o PDF do ASO decriptado numa nova aba. O endpoint confere pelo token que
// quem está pedindo não é um gestor — se for, a própria API recusa (403).
async function viewAso(matricula) {
  try {
    const token = await auth.currentUser.getIdToken();
    const resp = await fetch(`${ROBOZINHO_API}?matricula=${encodeURIComponent(matricula)}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!resp.ok) {
      const body = await resp.json().catch(() => ({}));
      showToast(body.error || 'Não foi possível abrir o ASO.', true);
      return;
    }
    const blob = await resp.blob();
    const url = URL.createObjectURL(blob);
    window.open(url, '_blank');
    // o objeto ainda existe na aba nova; liberamos a memória depois de um tempo generoso
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  } catch (e) {
    showToast('Não foi possível abrir o ASO: ' + e.message, true);
  }
}

function renderLogin(errorMsg) {
  const app = document.getElementById('app');
  app.innerHTML = `
    <div class="login-wrap">
      <div class="login-box">
        <div class="eyebrow">Controle de Saúde Ocupacional</div>
        <h1 class="display">Entrar no painel</h1>
        <div class="login-error">${errorMsg ? escapeHtml(errorMsg) : ''}</div>
        <label class="field-label">E-mail</label>
        <input class="field-input" id="login-email" type="email" placeholder="voce@empresa.com">
        <label class="field-label">Senha</label>
        <input class="field-input" id="login-senha" type="password">
        <button class="modal-primary" style="background:#1A1A1A" id="login-btn">Entrar</button>
      </div>
    </div>`;
  document.getElementById('login-btn').onclick = doLogin;
  document.getElementById('login-senha').addEventListener('keydown', e => { if (e.key === 'Enter') doLogin(); });
}

async function doLogin() {
  const email = document.getElementById('login-email').value.trim();
  const senha = document.getElementById('login-senha').value;
  try {
    await signInWithEmailAndPassword(auth, email, senha);
  } catch (e) {
    renderLogin('Não foi possível entrar. Confira e-mail e senha.');
  }
}

onAuthStateChanged(auth, async (user) => {
  if (user) {
    document.getElementById('app').innerHTML = '<div class="loading">Carregando registros…</div>';
    await checkManagerStatus();
    if (!state.isManager) await seedIfEmpty();
    listenToEmployees();
  } else {
    if (unsubscribeSnapshot) { unsubscribeSnapshot(); unsubscribeSnapshot = null; }
    if (unsubscribeSyncMeta) { unsubscribeSyncMeta(); unsubscribeSyncMeta = null; }
    state.syncMeta = null;
    state.isManager = false;
    state.managerSetor = null;
    state.managerDepartamento = null;
    renderLogin();
  }
});
